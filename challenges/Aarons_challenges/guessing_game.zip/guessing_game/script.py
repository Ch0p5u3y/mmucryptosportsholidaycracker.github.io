flag = "MMU{GUESSME}"

N = 393050634124102232869567034555427371542904833
e = 65537

for char in flag:
	print(pow(ord(char), e, N))
